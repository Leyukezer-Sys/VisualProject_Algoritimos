﻿// João faz 2 gols a cada jogo, enquanto Lucas faz 3 gols por
//jogos.João já tem 25 gols, e Lucas terá mais gols;

int golsjoao = 0, golsluca = 0, cont=0;

do
{

} while (golsjoao == 25);